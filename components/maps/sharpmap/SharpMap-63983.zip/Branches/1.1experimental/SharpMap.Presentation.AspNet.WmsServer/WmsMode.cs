﻿
namespace SharpMap.Presentation.AspNet.WmsServer
{
    public enum WmsMode
    {
        Capabilites,
        Map
    }
}
