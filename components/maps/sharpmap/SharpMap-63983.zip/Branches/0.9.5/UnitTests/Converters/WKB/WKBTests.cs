using System;
using GeoAPI.Geometries;
using NUnit.Framework;
using SharpMap.Converters.WellKnownText;
using SharpMap.Converters.WellKnownBinary;

namespace UnitTests.Converters.WKB
{
	[TestFixture]
	public class WKBTests
	{
		string multiLinestring = "MULTILINESTRING((10 10,40 50),(20 20,30 20),(20 20,50 20,50 60,20 20))";
		string linestring = "LINESTRING(20 20,20 30,30 30,30 20,40 20)";
		string polygon = "POLYGON((20 20,20 30,30 30,30 20,20 20),(21 21,21 29,29 29,29 21,21 21))";
		string point = "POINT(20.564 346.3493254)";
		string multipoint = "MULTIPOINT(20.564 346.3493254,45 32,23 54)";

		[Test]
		public void Convert()
		{
			IGeometry gML0 = GeometryFromWKT.Parse(multiLinestring);
			IGeometry gLi0 = GeometryFromWKT.Parse(linestring);
			IGeometry gPl0 = GeometryFromWKT.Parse(polygon);
			IGeometry gPn0 = GeometryFromWKT.Parse(point);
			IGeometry gMp0 = GeometryFromWKT.Parse(multipoint);
			IGeometry gML1 = GeometryFromWKB.Parse(gML0.AsBinary());
			IGeometry gLi1 = GeometryFromWKB.Parse(gLi0.AsBinary());
			IGeometry gPl1 = GeometryFromWKB.Parse(gPl0.AsBinary());
			IGeometry gPn1 = GeometryFromWKB.Parse(gPn0.AsBinary());
			IGeometry gMp1 = GeometryFromWKB.Parse(gMp0.AsBinary());
			Assert.AreEqual(gML0, gML1);
			Assert.AreEqual(gLi0, gLi1);
			Assert.AreEqual(gPl0, gPl1);
			Assert.AreEqual(gPn0, gPn1);
			Assert.AreEqual(gMp0, gMp1);
		}
	}
}
