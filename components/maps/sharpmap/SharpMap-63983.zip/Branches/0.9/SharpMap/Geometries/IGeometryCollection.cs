// Copyright 2005, 2006 - Morten Nielsen (www.iter.dk)
//
// This file is part of SharpMap.
// SharpMap is free software; you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// SharpMap is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with SharpMap; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 

using System;
using System.Collections.Generic;
using System.Text;

namespace SharpMap.Geometries
{
	/// <summary>
	/// Interface for a GeometryCollection. A GeometryCollection is a collection of 1 or more geometries.
	/// </summary>
	public interface IGeometryCollection : IGeometry
	{
		/// <summary>
		/// Returns the number of geometries in the collection.
		/// </summary>
		int NumGeometries{ get; }
		/// <summary>
		/// Returns an indexed geometry in the collection
		/// </summary>
		/// <param name="N">Geometry index</param>
		/// <returns>Geometry at index N</returns>
		Geometry Geometry(int N);	
	}
}
