This version of the assembly has been modified to allow partially trusted callers.

According to this article (http://help.godaddy.com/article/1039) GoDaddy opens up WebPermission which is the permission needed to use WebRequest objects.  Other hosting providers seem to follow this approach, so a fix based on this may be reusable for other clients.
 
Accordingly, Exec has been modified so that it uses WebRequest instead of sockets.
 
To use this assembly you must specify <trust level="Medium" originUrl=".*"/> in web.config (configuration/system.web).  No other changes are required.