***Please Note: Client Id, password and server references are contained in MQServers.cs. 
AT A MINIMUM, YOU WILL NEED TO CHANGE THE CLIENT ID/PASSWORD VALUES DEFINED IN THIS FILE 
BEFORE EXECUTING THE SAMPLES.  Please refer to your welcome letter for details.
