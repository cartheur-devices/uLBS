
INSTALL_BASE_DIR="mq/"
SOURCE_BASE_DIR=""
INSTALL_DIRS="bin docs ini libs logs pids sessions stats "
INSTALL_BASE_DIR="mq/"
INSTALL_BIN_DIR="/bin"
INSTALL_DATA_DIR="/data"
INSTALL_DOCS_DIR="/docs"
INSTALL_INI_DIR="/ini"
INSTALL_LIBS_DIR="libs"
INSTALL_LOGS_DIR="logs"
INSTALL_PIDS_DIR="pids"
INSTALL_SAMPLES_DIR="samples"
INSTALL_SESSIONS_DIR="sessions"
INSTALL_STATS_DIR="stats"
INSTALL_STYLE_DIR="style"
INSTALL_ODBC_DIR="/"
INI_SRC_FILES="server/mqlistener.ini  server/mqserver.ini  "
LIN_BIN_SRC_FILES="server/linux/mqlistener server/startmq"
LIN_LIBS_SRC_FILES="server/linux/libdatasel.so server/linux/libdatio.so server/linux/libDrivingDirections.so server/linux/libgeocd.so server/linux/libmap.so  server/linux/libProjections.so  server/linux/libtool.so  server/linux/libutil.so server/erroreng.txt server/aapi1_0.xsd"
LIN_ODBC_SRC_FILES="odbc/linux/unixODBC-2.2.8"

INPUT=
KEYCODE=
INSTALL_ODBC=true
INSTALL_SERVER=true
retVal=

############################################################
quit()
############################################################
{
   exit
}

############################################################
showMsg()
############################################################
{
   echo $1
}

############################################################
showNL()
############################################################
{
   echo ""
}

############################################################
showIntro()
############################################################
{
   echo " "
   echo "*==============================================================="
   echo "* This will interactively install MapQuest Advantage Enterprise."
   echo "* You will be prompted  for components to install"
   echo "* and where to install them."
   echo "* "
   echo "* You may press 'q' at any prompt to quit the"
   echo "* installation"
   echo "* "
   echo "* Type 'setup -help' to get help and examples"
   echo "* "
   echo "* IMPORTANT - It is strongly recommended that you "
   echo "*             install this software into a directory " 
   echo "*             that does not contain a previous version  "
   echo "*             of MapQuest Advantage Enterprise."
   echo "*==============================================================="
   echo " "
}

############################################################
showInstallCompleteMsg()
############################################################
{
   showHeader "MapQuest Advantage Enterprise succesfully installed"
                     
   showMsg "NOTE: Be sure to insert your keycode into the mqserver.ini file"
   showMsg "Link/install data into 'data' directory"
   showMsg "Edit config files in 'ini' directory"
   showMsg ""
   showMsg "run 'startmq' in 'bin' directory to start server"
   showMsg ""
}

############################################################
getYNOrQuit()
############################################################
{
   YN=
   FINISH=0
   while [ $FINISH -ne 1 ]
   do
      printf "%s" "$1"
      read YN
      if [ $YN ]
      then 
         if [ $YN = "y" -o $YN = "n" -o $YN = "q" ]
         then
            FINISH=1
            continue
         fi 
      else
         continue
      fi
   done
}

############################################################
getInput()
############################################################
{
   FINISH=0
   while [ $FINISH -ne 1 ]
   do
      printf "%s" "$1"
      read INPUT
      if [ INPUT ]
      then
         if [ $INPUT ]
         then
            FINISH=1
         fi 
      fi 
      continue
   done  
}

############################################################
getInputVerify()
############################################################
{
   FINISH=0
   while [ $FINISH -ne 1 ]
   do
      printf "%s" "$1"
      read INPUT
      if [ INPUT ]
      then
         if [ "$INPUT" != "" ]
         then
            if [ "$INPUT" = "q" ]
            then
               quit
            else
               printf "\n"
               YN="n"
               getYNOrQuit "Is this correct? (y/n/q) :"
               printf "\n"
               FINISH=0
               if [ $YN = "q" ]
               then
                     quit
               else
                  if [ $YN = "y" ]
                  then
                     FINISH=1
                  fi
               fi             
            fi 
         fi 
      fi 
      continue
   done  
}

############################################################
showHeader()
############################################################
{
   echo " "
   echo "*===================================================="
   echo "* $1"
   echo "*===================================================="
   echo " "
}

############################################################
getOS()
############################################################
{
   OSTYPE="linux"
}

############################################################
checkDirExists()
############################################################
{
   if [ -d $1 ] 
   then
      retVal="true"
   else
      retVal="false"
   fi;   
}

############################################################
checkDirReadable()
############################################################
{
   if [ -r $1 ] 
   then
      retVal="true"
   else
      retVal="false"
   fi;   
}

############################################################
checkDirWriteable()
############################################################
{
   if [ -w $1 ] 
   then
      retVal="true"
   else
      retVal="false" 
   fi;   
}

############################################################
createDir()
############################################################
{
   if [ -d $1 ] 
   then
      retVal="true"   
   else
      mkdir $1 
      retVal="false"
      checkDirExists $1
      if [  $retVal = "true" ]
      then
         retVal="true"   
      else
         retVal="false"   
      fi   
   fi 
}

############################################################
checkFileExists()
############################################################
{
   if [ -s "$1" ] 
   then
      retVal="true"
   else
      retVal="false"
   fi;   
}

############################################################
checkFileReadable()
############################################################
{
   if [ -r $1 ] 
   then
      retVal="true"
   else
      retVal="false"
   fi;   
}

############################################################
checkFileWriteable()
############################################################
{
   if [ -w $1 ] 
   then
      retVal="true"
   else
      retVal="false" 
   fi;   
}

############################################################
initInstall()
############################################################
{
   showHeader "MapQuest Advantage Enterprise Version 5.1 for $OSTYPE"

   showIntro
   YN="n"
   getYNOrQuit "Would you like to continue? (y/n/q) :"
   if [ $YN = "q" -o $YN = "n" ]
   then
      quit
   fi   
   
   showNL
   showMsg "Checking for nessecary tools..."
   showNL
   retVal="false"
   d2uExists=`which dos2unix`
   if [ ! -x "$d2uExists" ]
   then
      showMsg "Failed to find dos2unix. quitting..."
      quit
   fi 
   
   retVal="false"
   awkExists=`which awk`
   if [ ! -x "$awkExists" ]
   then
      showMsg "Failed to find awk. quitting..."
      quit
   fi 
   
   showMsg "OK"   
}

############################################################
getUserInstallOpts()
############################################################
{
   YN="n" 
   while [ ! "$YN" = "y" ]
   do
      showHeader "Options for installation"
   
      getYNOrQuit "Install server? (y/n/q) : "
      if [ $YN = "q" ]
      then
         quit
      else
         if [ $YN = "y" ]
         then
            INSTALL_SERVER="true"
         else  
            INSTALL_SERVER="false"
         fi 
      fi
   
      showMsg ""
      getInputVerify "Enter path where programs are to be installed to, including the trailing '/'.(ie. /usr/local/mq/ ) : "
      if [ $INPUT = "q" ]
      then
         quit
      else
         INSTALL_BASE_DIR=$INPUT
      fi
   
      DONE=0
      while [ $DONE = 0 ]
      do
         getInputVerify "Enter path where programs are to be installed from (ie. /mnt/cdrom ) : "
         if [ $INPUT = "q" ]
         then
            quit
         else
            SOURCE_BASE_DIR=$INPUT
            retVal="false"
            checkDirExists $SOURCE_BASE_DIR 
            if [ $retVal = "false" ] 
            then
               showMsg "Source directory \"$SOURCE_BASE_DIR\" does not exist"
               showNL
               continue
            fi
               
            retVal="false"
            checkDirReadable $SOURCE_BASE_DIR
            if [ $retVal = "false" ] 
            then
               showMsg "Source directory \"$SOURCE_BASE_DIR\" is not readable"
               showNL
               continue
            fi
            DONE=1
         fi
      done
   
      showNL
      showMsg "INSTALL SERVER = $INSTALL_SERVER"
      showMsg "INSTALLATION  DIR = $INSTALL_BASE_DIR"
      showMsg "SOURCE DIR = $SOURCE_BASE_DIR"
      showNL
      getYNOrQuit "Are these correct? (y/n/q) :"
   
      if [ $YN = "q" ]
      then
         quit
      fi
   done

}

############################################################
verifyUserInstallOpts()
############################################################
{
   showHeader "Verifying installation options"  
   showB2BInstallOpts
   
   if [ $INSTALL_SERVER = "false" ]
   then
         showMsg "Nothing to install, quitting..."
         quit
   fi

   if [ ! $SOURCE_BASE_DIR  ]
   then
      showMsg "No source directory given, quitting..."
      quit
   fi

   showMsg "OK"
}

############################################################
createDirs()
############################################################
{
   showHeader "Initializing install"   
                     
   retVal="false"
   checkDirExists $INSTALL_BASE_DIR
   if [ $retVal = "false" ] 
   then
      retVal="false"
      createDir $INSTALL_BASE_DIR
      if [ $retVal = "false" ] 
      then
         showMsg "Install directory \"$INSTALL_BASE_DIR\" does not exist, and unable to create it"
         quit
      fi
   fi
         
   retVal="false"
   checkDirWriteable $INSTALL_BASE_DIR
   if [ $retVal = "false" ] 
   then
      showMsg "Install directory \"$INSTALL_BASE_DIR\" is not writeable"
      quit
   fi

   for dir in $INSTALL_DIRS
   do
      retVal="false"
      checkDirExists $INSTALL_BASE_DIR/$dir
      if [ $retVal = "false" ] 
      then
         retVal="false"
         createDir $INSTALL_BASE_DIR/$dir
         if [ $retVal = "false" ] 
         then
            showMsg "Install directory \"$INSTALL_BASE_DIR/$dir\" does not exist, and unable to create it"
            quit
         fi
      fi
   done
   
   showMsg "OK"
}  

############################################################
copySource()
############################################################
{
   showHeader "Copying files" 

   if [ $INSTALL_SERVER = "true" ] 
   then
   
      # Binaries
      for curFile in $BIN_SRC_FILES
      do
         cp -p $SOURCE_BASE_DIR/$curFile $INSTALL_BASE_DIR/$INSTALL_BIN_DIR/. 
      done
      
      #Docs
      for curFile in $DOCS_SRC_FILES
      do
         cp -Rp $SOURCE_BASE_DIR/$curFile $INSTALL_BASE_DIR/$INSTALL_DOCS_DIR/. 
      done
      
      # Ini files
      for curFile in $INI_SRC_FILES
      do
         cp -Rp $SOURCE_BASE_DIR/$curFile $INSTALL_BASE_DIR/$INSTALL_INI_DIR/. 
      done
      
      # Libraries
      for curFile in $LIBS_SRC_FILES
      do
         cp -Rp $SOURCE_BASE_DIR/$curFile $INSTALL_BASE_DIR/$INSTALL_LIBS_DIR/. 
      done
      
      #ODBC
      for curFile in $ODBC_SRC_FILES
      do
         cp -Rp $SOURCE_BASE_DIR/$curFile $INSTALL_BASE_DIR/$INSTALL_ODBC_DIR/. 
      done
   fi
  
   showMsg "OK"
}

############################################################
generateIni()
############################################################
{
   showHeader "Updating mqserver.ini" 
   
   INI_FQN=$INSTALL_BASE_DIR$INSTALL_INI_DIR/mqserver.ini
   KC=""
   
   YN="n"
   while [ $YN = "n" ]
   do
      getInput "Please enter your keycode : "
      if [ $INPUT = "q" ]
      then
         quit
      else
         getYNOrQuit "$INPUT, is this correct (y/n/q)"
      fi 
   done  
   
   KC=$INPUT
   showMsg ""
   
   retVal="false"
   checkFileExists $INI_FQN
   if [ $retVal = "false" ] 
   then
         DONE=0
         while [ $DONE -ne 1 ]
         do
            INPUT=""
            showMsg "File \"$INI_FQN\" does not exist"
            showMsg ""
            getInputVerify "Please enter the complete path to the mqserver.ini file (ie. /usr/local/mq/ini/mqserver.ini ) :"
            if [ $INPUT = "q" ]
            then
               quit
            else
               INI_FQN=$INPUT   
               retVal="false"
               checkFileExists $INI_FQN
               if [ $retVal = "true" ] 
               then
                  DONE=1
               fi
            fi
         done  
      fi
   
      retVal="false"
      checkFileReadable $INI_FQN
      if [ $retVal = "false" ] 
      then
            DONE=0
            while [ $DONE -ne 1 ]
            do
               INPUT=""
               showMsg "File \"$INI_FQN\" is not readable"
               showMsg ""
               getInputVerify "Please enter the complete path to the mqserver.ini file (ie. /usr/local/mq/ini/mqserver.ini ) :"
               if [ $INPUT = "q" ]
               then
                  quit
               else
                  INI_FQN=$INPUT   
                  retVal="false"
                  checkFileReadable $INI_FQN
                  if [ $retVal = "true" ] 
                  then
                     DONE=1
                  fi
               fi
            done  
      fi
   
      #KEYCODE
      `cp $INI_FQN $INI_FQN.bak`
       sed -e s/%KEYCODE/"$KC"/g $INI_FQN.bak > $INI_FQN
       
      #clear unused entries
      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[MapPool]" ) != 0 ) { 
         getline       
         printf("[MapPool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   
      
      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[MapDataSelectorPool]" ) != 0 ) { 
         getline             
         printf("[MapDataSelectorPool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   
      
      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[StylePool]" ) != 0 ) { 
         getline             
         printf("[StylePool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   
      
      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[Geocode]" ) != 0 ) { 
         getline             
         printf("[Geocode]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   

      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[GeocodeDataSelectorPool]" ) != 0 ) { 
         getline             
         printf("[GeocodeDataSelectorPool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   

      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[RoutePool]" ) != 0 ) { 
         getline             
         printf("[RoutePool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   

      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[RouteDataSelectorPool]" ) != 0 ) { 
         getline             
         printf("[RouteDataSelectorPool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   

      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[DBPool]" ) != 0 ) { 
         getline             
         printf("[DBPool]\nNumberOfPools=0\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   

      `cp $INI_FQN $INI_FQN.bak`
      `awk ' { if( index ( $0, "[Session]" ) != 0 ) { 
         getline             
         printf("[Session]\nModule=\n")
      }else{
         print
      }}' "$INI_FQN.bak" > "$INI_FQN"`   
   
   rm $INI_FQN.bak
   
   showMsg "OK"   
}

############################################################
finishInstall()
############################################################
{
   showHeader "Finalizing install"  

   # create the odbc symlink if installing server or odbc   
   if [ $INSTALL_SERVER = "true" -o $INSTALL_ODBC = "true" ]
   then
      cd $INSTALL_BASE_DIR/
      ln -s unixODBC-2.2.8 odbc
   fi 
   
   # setup the mqserver.ini file if installing server
   if [ $INSTALL_SERVER = "true" ]
   then
      `chmod 666 "$INSTALL_BASE_DIR/ini/mqserver.ini"`
      `dos2unix   $INSTALL_BASE_DIR/ini/mqserver.ini $INSTALL_BASE_DIR/ini/mqserver.ini 2> /dev/null`
      generateIni
   fi
   
   showInstallCompleteMsg
}

############################################################
#  main
############################################################

if [ "$OSTYPE" = "" -o "$OSTYPE" != "linux" ]
then
   getOS
fi 

if [ "$OSTYPE" = "linux" ]
then
   BIN_SRC_FILES=$LIN_BIN_SRC_FILES
   LIBS_SRC_FILES=$LIN_LIBS_SRC_FILES
   ODBC_SRC_FILES=$LIN_ODBC_SRC_FILES 
fi

initInstall
getUserInstallOpts
createDirs
copySource
finishInstall
