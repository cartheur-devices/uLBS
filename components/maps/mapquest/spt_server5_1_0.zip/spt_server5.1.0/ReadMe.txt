MapQuest Advantage Installation Instructions:

Windows Environment:
   Double click on the setup.exe file.
   
Linux Environment:
   Set the OSTYPE environment variable to "linux".
   Create a target directory into which the server is to be installed.
   Change directory to the mounted cdrom directory.
   To install the server, enter "sh setup.sh".

