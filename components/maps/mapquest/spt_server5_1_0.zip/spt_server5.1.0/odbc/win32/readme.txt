Windows installations come with ODBC built right into the operating 
system.  To ensure you have the lastest drivers go to Microsoft
download and install the latest MDAC update.    

Try here for more info http://www.microsoft.com/data/download.htm