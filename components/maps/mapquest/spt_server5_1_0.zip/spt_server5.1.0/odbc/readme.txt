-----------------------------------------------------------------------------
Open DataBase Connectivity (ODBC)
-----------------------------------------------------------------------------

For database connectivity Open DataBase Connectivity (ODBC) standard is used.
On Windows platforms the native operating system version of ODBC is used.  On
Unix platforms unixODBC (www.unixodbc.org) is used.  

The version built and tested with MapQuest Advantage Enterprise is 
unixODBC v 2.2.8.

ONLY use the provided version of unixODBC with MapQuest Advantage Enterprise.


Related Links

unixODBC       www.unixodbc.org           The unixODBC Project 
                                          Unix platform ODBC
                                          Check this site for other
                                          ODBC drivers.
                                          
MySQL          www.mysql.org              Open Source Database

MyODBC         www.mysql.org              ODBC driver for MySQL

Easysoft       www.easysoft.com           Commerical provider of other
                                          database drivers


-----------------------------------------------------------------------------
Building unixODBC (not recommended)
-----------------------------------------------------------------------------

Minor modifications to the stock version of unixODBC 2.2.8 were used to 
accommodate multithreaded use and thread local storage exhibited by the 
MyODBC MySQL driver.  Without the modifications, the server will exit after
an amount of strenuous database searches.


The modifications are as follows:

-----------------------------------------------------------------------------
diff -w unixODBC-2.2.8/DriverManager/SQLConnect.c SQLConnect.c

2330a2331
> /* MOD
2336a2338
> */
2395a2398
> /* MOD
2399c2402
<
---
> */

-----------------------------------------------------------------------------
Details of the changes
-----------------------------------------------------------------------------
2330a2331
> /* MOD
2336a2338
> */

    /*
     * now disconnect the environment, if its the last usage on the connection
     */

/* MOD
    if ( connection -> driver_env )
    {
        release_env( connection );
    }

    connection -> driver_env = (SQLHANDLE)NULL;
*/


2395a2398
> /* MOD
2399c2402
<
---
> */
void __disconnect_part_four( DMHDBC connection )
{
    /*
     * now disconnect the environment, if its the last usage on the connection
     */

/* MOD
    release_env( connection );

    connection -> driver_env = (SQLHANDLE)NULL;
*/
-----------------------------------------------------------------------------


When building unixODBC the following configure script was used.  

-----------------------------------------------------------------------------
conf_unixODBC :
-----------------------------------------------------------------------------
#!/bin/csh

# Run this script to build unixODBC 
# the script goes in the unixODBC root
#
# Files will be installed in /dev3/packages/unixODBC-2.2.8
#
# $1 some optional extension to siginfy this build


./configure --prefix=/dev3/packages/unixODBC-2.2.8$1 --sysconfdir=/dev3/packages/unixODBC-2.2.8$1


make
make install
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
end unixODBC
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
Building MyODBC MySQL Driver 
-----------------------------------------------------------------------------
Linux:

MySql Client
1.) extraction
cd /dev3/sandbox/jhughes/mysqlbuild/
gzip -d mysql-3.23.51.tar.gz
gtar -xvf mysql-3.23.51.tar
cd ./mysql-3.23.51

2.) Configuration:
configure --without-server --with-pthread --enable-thread-safe-client --prefix=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51 --localstatedir=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51/data --with-unixODBC-libs=/dev3/sandbox/jhughes/mysqlbuild/odbc/lib --with-unixODBC-includes=/dev3/sandbox/jhughes/mysqlbuild/odbc/include

3.) compilation:
make

4.) install
copy mt safe and single threaded clients.
cd libmysqlclient_r/.libs
cp libmysqlclient_r.s* /dev3/sandbox/jhughes/mysqlbuild/odbc/lib
cd ../../libmysqlclient/.libs
cp libmysqlclient.s* /dev3/sandbox/jhughes/mysqlbuild/odbc/lib

MyODBC Driver
1.) extraction
cd /dev3/sandbox/jhughes/mysqlbuild
gzip -d MyODBC-3.51.03.tar.gz
gtar -xvf MyODBC-3.51.03.tar
cd MyODBC-3.51.03

2.) Configuration:
configure --without-debug --with-thread-safe-client --prefix=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51 --with-mysql-dirs=/dev3/sandbox/jhughes/mysqlbuild/odbc --with-mysql-libs=/dev3/sandbox/jhughes/mysqlbuild/odbc/lib --with-mysql-includes=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51/include --with-unixODBC=/dev3/sandbox/jhughes/mysqlbuild/odbc

Then change makefile:
Add defines -DDBUG_OFF -DTHREAD

change:
LDFLAFS = -L/dev3/sandbox/jhughes/mysqlbuild/odbc/lib -lmysqlclient
to:
LDFLAFS = -L/dev3/sandbox/jhughes/mysqlbuild/odbc/lib -lmysqlclient_r

3.) compilation:
make

4.) Install:
cd .libs
cp libmyodbc3.so ../../odbc/lib/.
cp libmyodbc3-3.51.03.so ../../odbc/lib/.


MyODBC Driver
1.) extraction
cd /dev3/sandbox/jhughes/mysqlbuild
gzip -d MyODBC-3.51.03.tar.gz
gnutar -xvf MyODBC-3.51.03.tar
cd MyODBC-3.51.03

2.) Configuration:
configure --without-debug --with-thread-safe-client --prefix=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51 --with-mysql-dirs=/dev3/sandbox/jhughes/mysqlbuild/odbc --with-mysql-libs=/dev3/sandbox/jhughes/mysqlbuild/odbc/lib --with-mysql-includes=/dev3/sandbox/jhughes/mysqlbuild/mysql-3.23.51/include --with-unixODBC=/dev3/sandbox/jhughes/mysqlbuild/odbc

Then change makefile:
Add defines -DDBUG_OFF -DTHREAD

change:
LDFLAFS = -L/dev3/sandbox/jhughes/mysqlbuild/odbc/lib -lmysqlclient
to:
LDFLAFS = -L/dev3/sandbox/jhughes/mysqlbuild/odbc/lib -lmysqlclient_r

3.) compilation:
make

4.) Install:
cd .libs
cp libmyodbc3.so ../../odbc/lib/.
cp libmyodbc3-3.51.03.so ../../odbc/lib/.



***************MYODBC FILE CHANGE:
error.c
modified SQLError function - replaced hbdc Clear_STMT with CLEAR_DBC and CLEAR_ENV
IT SHOULD BE:

SQLRETURN SQL_API SQLError(SQLHENV henv, SQLHDBC hdbc, SQLHSTMT hstmt,
            SQLCHAR FAR    *szSqlState,
            SQLINTEGER FAR *pfNativeError,
            SQLCHAR FAR    *szErrorMsg,
            SQLSMALLINT    cbErrorMsgMax,
            SQLSMALLINT FAR *pcbErrorMsg)
{
  SQLRETURN error=SQL_INVALID_HANDLE;
  DBUG_ENTER("SQLError");

  if (hstmt){
    error = my_SQLGetDiagRec(SQL_HANDLE_STMT,hstmt,1,szSqlState,
                             pfNativeError, szErrorMsg,
                             cbErrorMsgMax,pcbErrorMsg);
    if(error == SQL_SUCCESS)
      CLEAR_STMT_ERROR(((STMT FAR*)hstmt));
  }
  else if (hdbc){
    error = my_SQLGetDiagRec(SQL_HANDLE_DBC,hdbc,1,szSqlState,
                             pfNativeError, szErrorMsg,
                             cbErrorMsgMax,pcbErrorMsg);
    if(error == SQL_SUCCESS)
      CLEAR_DBC_ERROR(((DBC FAR*)hdbc));
  }
  else if (henv){
    error = my_SQLGetDiagRec(SQL_HANDLE_ENV,henv,1,szSqlState,
                             pfNativeError, szErrorMsg,
                             cbErrorMsgMax,pcbErrorMsg);
    if(error == SQL_SUCCESS)
      CLEAR_ENV_ERROR(((ENV FAR*)henv));
  }
  DBUG_RETURN(error);
}

-----------------------------------------------------------------------------
end MyODBC
-----------------------------------------------------------------------------
